export { default } from './ProductList';
