export { default } from './TotalUsers';
